<?php
    require __DIR__ . './vendor/autoload.php';)

    //$transport = Swift_SendmailTransport::newInstance('/usr/sbin/sendmail -bs');
    //$transport = Swift_MailTransport::newInstance();
    $transport = Swift_SmtpTransport::newInstance('smtp.gmail.com', 465, 'ssl')
        ->setUsername('riffcamailer@gmail.com')
        ->setPassword('riffcamailer3286030'));

    $mailer = Swift_Mailer::newInstance($transport);

    $message = Swift_Message::newInstance('Новая заявка на Фото')
        ->setFrom(['riffcamailer@gmail.com' => 'Фото заявка'])
        ->setTo(['riffca@yandex.ru', 'anna-pliusnina@mail.ru'])
        ->setBody("Заявка от Феди \n\n Контакт: 323");

    $result = $mailer->send($message);

        if($result > 0) {
            echo 'yes';
        } else {
            echo 'no';
        }

